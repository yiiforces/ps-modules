<?php
/*
 * 2007-2015 PrestaShop
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please refer to http://www.prestashop.com for more information.
 *
 *  @author PrestaShop SA <contact@prestashop.com>
 *  @copyright  2007-2015 PrestaShop SA

 *  @license    http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 *  International Registered Trademark & Property of PrestaShop SA
 */

trait TraitDisplayshippingtimeValidator
{
    public function encode($content, $doubleEncode = true)
    {
        return
            htmlspecialchars($content, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8', $doubleEncode);
    }

    protected function validateUrl($value)
    {
        $pattern = '/^(http|https):\/\/(([A-Z0-9][A-Z0-9_-]*)(\.[A-Z0-9][A-Z0-9_-]*)+)(?::\d{1,5})?(?:$|[?\/#])/i';
        return (preg_match($pattern, $value));
    }

    protected function validateRequired($value)
    {
        return
            ($value === null || $value === [] || $value === '') ? false : true;
    }

    protected function validateNumber($value)
    {
        return
            preg_match('/^(\d{1,})$/', $value);
    }

    protected function validate($type, &$value)
    {
        try{
            $value = (string) $value;
            $value = trim($value);
            $value = $this->encode($value);

            switch($type)
            {
                case 'url':
                    return $this->validateUrl($value);

                case 'required':
                    return $this->validateRequired($value);

                case 'number':
                    return $this->validateNumber($value);

                default:
                    return true;
            }

        }
        catch(Exception $e){
           $value = '';
           return false;
        }
    }
}

trait TraitDisplayshippingtimeConfigure
{
    protected function getConfig($refresh = false)
    {
        if(empty($this->_config) || $refresh == true )
            $this->loadConfig();

        return $this->_config;
    }

    protected function loadConfig()
    {
        $dbConfig      = Configuration::get(static::KEY_CONFIG);
        $this->_config = ($dbConfig == false) ? static::DEFAULT_CONFIG : json_decode($dbConfig, true);
    }

    protected function saveConfig($params = [])
    {
        $json = json_encode($params);
        $status = Configuration::updateValue(static::KEY_CONFIG, $json);

        if($status == false)
            return false;

        // @todo update all cache:
        return $status;
    }

    protected function getConfigValue($key)
    {
        return (isset($this->_config[$key])) ? $this->_config[$key] : '';
    }
}

trait TraitDisplayshippingtimeQuery
{
    protected function createTableCache()
    {
        $sql = '
            CREATE TABLE IF NOT EXISTS {dbPrefix}product_shipping_time_cache(
                id              integer   unsigned  NOT NULL AUTO_INCREMENT,
                id_product      integer   unsigned  not null,
                id_combination  integer   unsigned  default null,
                `date`          date      default null,
                quantity_date   date      default null,
                quantity        integer   unsigned  default null,
                expire_at       integer   unsigned  default null,
                primary key (id),

                UNIQUE KEY unq1_{dbPrefix}product_shipping_time_cache (id_product, id_combination),
                KEY key1_{dbPrefix}product_shipping_time_cache (id_product),
                KEY key2_{dbPrefix}product_shipping_time_cache (id_combination),
                KEY key3_{dbPrefix}product_shipping_time_cache (expire_at),
                CONSTRAINT fk1_{dbPrefix}product_shipping_time_cache  FOREIGN KEY (id_product) REFERENCES {dbPrefix}product (id_product) on delete cascade on update cascade
            )ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
        ';

        $sql = preg_replace('<({dbPrefix})>', _DB_PREFIX_, $sql);
        try{ Db::getInstance()->execute($sql, false); }
        catch(\Exception $e){ return false; }

        return true;
    }

    protected function dropTableCache()
    {
        $sql = 'DROP TABLE IF EXISTS {dbPrefix}product_shipping_time_cache';
        $sql = preg_replace('<({dbPrefix})>', _DB_PREFIX_, $sql);
        try{ Db::getInstance()->execute($sql, false); }
        catch(\Exception $e){ return false; }
        return true;
    }

    protected function getCarrierTime($idShop)
    {
        $idShop = (int) $idShop;

        $sql =  '
            select distinct ct.times from {dbPrefix}carrier_times ct
            inner join {dbPrefix}carrier as c on c.id_reference = ct.id_carrier

            where ct.id_shop = {idShop}
            and c.deleted    = 0
            order by times asc limit 1

        ';
        $sql  = preg_replace(['<({dbPrefix})>' , '<({idShop})>'], [_DB_PREFIX_ , $idShop] , $sql);
        $data = Db::getInstance()->executeS($sql, true, false);
        if(empty($data))
            return false;

        return $data[0]['times'];
    }
}

trait TraitDisplayshippingtimeApiRequest
{
    public function apiGetData($idProduct, $idCombination =  null)
    {
        if(empty($idProduct))
            return false;

        if($idCombination <= 0)
            $idCombination = null;

        $dataEndpoint = false;
        $dataCache    = false;

        if($idCombination == null)
            $sql = ' select * from {tableName} where id_product = ' . (int) $idProduct . ' and id_combination is null';
        else
            $sql = ' select * from {tableName} where id_product = ' . (int) $idProduct . ' and id_combination = ' . (int) $idCombination;

        $sql       = preg_replace('<({tableName})>', _DB_PREFIX_ . 'product_shipping_time_cache', $sql);
        $dataCache = Db::getInstance()->getRow($sql, false);

        if($dataCache === false)
            return $this->apiGetDataFromEndpoint($idProduct, $idCombination);

        if($this->_config['cache_timelive'] > 0 && $dataCache['expire_at'] <= strtotime( date('Y-m-d H:i:s') ))
            $dataEndpoint = $this->apiGetDataFromEndpoint($idProduct, $idCombination);

        return ($dataEndpoint === false) ? $dataCache : $dataEndpoint;
    }

    protected function apiGetDataFromEndpoint($idProduct, $idCombination =  null)
    {
        $authBasic = base64_encode(sprintf('%s:%s', $this->_config['client_id'], $this->_config['client_secrect']));
        $params    = (empty($idCombination)) ? ['id_product' => $idProduct] : ['id_product' => $idProduct, 'id_combination' => $idCombination];
        $url       = $this->_config['endpoint'];
        $url      .= '?' . http_build_query($params);

        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_HTTPHEADER, ['Authorization: Basic ' . $authBasic ]);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        $result = curl_exec($curl);
        $info   = curl_getinfo($curl);
        curl_close($curl);

        if($info['http_code'] != 200)
            return false;

        try{
            $data = json_decode($result, true);
        }
        catch(Exception $e){
            return false;
        }

        if($idCombination == null)
            Db::getInstance()->delete('product_shipping_time_cache' , 'id_product = ' . (int) $idProduct . ' and id_combination is null' );
        else
            Db::getInstance()->delete('product_shipping_time_cache' , 'id_product = ' . (int) $idProduct . ' and id_combination = ' .  (int) $idCombination );

        $data['id_combination'] = $idCombination;
        $data['id_product']     = $idProduct;
        $data['expire_at']      = $this->getNextExpireTime();

        $idCombination = empty($idCombination)          ? 'null' : (int) $idCombination;
        $date          = empty($data['date'])           ? 'null' : '"'.  $data['date'] .'"';
        $quantity_date = empty($data['quantity_date'])  ? 0      : '"'.  $data['quantity_date'] .'"';
        $quantity      = empty($data['quantity'])       ? 'null' : (int) $data['quantity'];
        $expire_at     = (empty( $data['expire_at'] ))  ? 'null' : $data['expire_at'];

        $sql = sprintf(
            'insert into %sproduct_shipping_time_cache (id_product, id_combination, date, quantity_date, quantity, expire_at) values (%s,%s,%s,%s,%s, %s)',
            _DB_PREFIX_ , $idProduct, $idCombination, $date , $quantity_date, $quantity, $expire_at
        );

        try{ Db::getInstance()->execute($sql);}
        catch(Exception $e){}
        return $data;
    }

    protected function getNextExpireTime()
    {
        if($this->_config['cache_timelive'] <= 0)
            return null;

        $now = date('Y-m-d H:i:s');
        return strtotime ( '+ '. $this->_config['cache_timelive'] .' hour' , strtotime ($now) );
    }
}

class Displayshippingtime extends Module
{
    use TraitDisplayshippingtimeQuery;
    use TraitDisplayshippingtimeConfigure;
    use TraitDisplayshippingtimeValidator;
    use TraitDisplayshippingtimeApiRequest;

    const FORM_ACTION_SUBMIT = 'displayshippingtime_form';
    const HOOK_TARGET        = 'displayShippingTime';
    const KEY_CONFIG         = 'displayShippingTime_config';

    // struct config
    const DEFAULT_CONFIG = [
        'endpoint'          => 'https://decantalo.test.planetatic.com/prestashop/product_shipping_dates',   // ENDPOINT API
        'client_id'         => 'webimpacto',                                                                // AUTH_USER
        'client_secrect'    => 'wim2020!',                                                                  // PASSW_USER
        'cache_timelive'    => 6,                                                                           // TIEMPO DE VIDA DEL CACHE EN DB
        'exclude_days'      => [6,7], // DIAS EXCLUIDOS PARA SACAR CUENTA EN CUANTO TARDA EN LLEGAR
    ];

    public  $form    = [];
    private $_config = [];

    public function __construct()
    {
        $this->name                   = 'displayshippingtime';
        $this->author                 = 'Webimpacto';
        $this->version                = '1.0';
        $this->controllers            = array('default');
        $this->bootstrap              = true;
        $this->need_instance          = 1;
        $this->displayName            = $this->l('Product display shipping time');
        $this->description            = $this->l('Muestra el tiempo de entrega en el frontend para un producto (hook '. static::HOOK_TARGET .')');
        $this->confirmUninstall       = $this->l('Estas seguro de eliminar este modulo?');
        $this->ps_versions_compliancy = array('min' => '1.6', 'max' => _PS_VERSION_);
        $this->_config                = $this->getConfig();
        parent::__construct();
    }

    public function install()
    {
        return
            ((!parent::install() ||  !$this->createTableCache() || !$this->registerHook( static::HOOK_TARGET )) ? false : true);
    }

    public function unistall()
    {
        return
            ((!parent::unistall() || !$this->dropTableCache() || !$this->unregisterHook( static::HOOK_TARGET )) ? false : true);
    }

    public function getForm()
    {
        $form = new HelperForm();
        $form->module                   = $this;
        $form->name_controller          = $this->name;
        $form->identifier               = $this->identifier;
        $form->token                    = Tools::getAdminTokenLite('AdminModules');
        $form->languages                = $this->context->controller->getLanguages();
        $form->currentIndex             = AdminController::$currentIndex . '&configure=' . $this->name;
        $form->default_form_language    = $this->context->controller->default_form_language;
        $form->allow_employee_form_lang = $this->context->controller->allow_employee_form_lang;
        $form->title                    = $this->displayName;
        $form->submit_action            = static::FORM_ACTION_SUBMIT;

        array_push($this->form, [
            'form' => [
                'legend' => ['title' => $this->displayName ],
                'submit' => ['title' => $this->l('Save')   ],
                'input'  => $this->formInputs($form)
            ]
        ]);

        return $form->generateForm($this->form);
    }

    public function getContent()
    {
        return
            $this->processForm() . $this->getForm();
    }

    protected function processForm()
    {
        if( Tools::isSubmit(static::FORM_ACTION_SUBMIT)  == false)
            return;

        $errors = [];

        $endpoint       = Tools::getValue('endpoint');
        $client_id      = Tools::getValue('client_id');
        $client_secrect = Tools::getValue('client_secrect');
        $cache_timelive = Tools::getValue('cache_timelive');

        if($this->validate('url', $endpoint) == false)
            $errors[] = $this->l('Api endpoint URL debe no es una url valida');

        if($this->validate('required', $client_id) == false)
            $errors[] = $this->l('Client id es un valor requerido');

        if($this->validate('required', $client_secrect) == false)
            $errors[] = $this->l('Client secret es un valor requerido');

        if($this->validate('number', $cache_timelive) == false)
            $errors[] = $this->l('Tiempo de vida del cache en horas no es un valor entero >= 0');

        else if($cache_timelive < 0)
            $errors[] = $this->l('Tiempo de vida del cache en horas no es un valor entero >= 0');

        else if($cache_timelive > 999)
            $errors[] = $this->l('Tiempo de vida del cache en horas debe ser menor ó igual a 999');

        if(!empty($errors))
            return $this->displayError($errors);

        $status = $this->saveConfig([
            'endpoint'       => $endpoint,
            'client_id'      => $client_id,
            'client_secrect' => $client_secrect,
            'cache_timelive' => $cache_timelive,
        ]);

        if($status == true)
            return $this->displayConfirmation( $this->l('Updated Successfully') );
        else
            return $this->displayWarning( $this->l('Error al intentar guardar los datos. favor intente nuevamente') );
    }

    protected function formInputs(&$form)
    {
        $inputs = [];

        // endpoint
        array_push($inputs, [
            'type'          => 'text',
            'label'         => $this->l('Api endpoint URL'),
            'desc'          => $this->l('Api endpoint URL'),
            'hint'          => $this->l('Api endpoint URL'),
            'required'      => true,
            'name'          => 'endpoint',
            'lang'          => false,
            'empty_message' => $this->l('Este campo es requerido'),
        ]);

        // client_id
        array_push($inputs, [
            'type'          => 'text',
            'label'         => $this->l('Client id'),
            'desc'          => $this->l('Client id'),
            'hint'          => $this->l('Client id'),
            'required'      => true,
            'name'          => 'client_id',
            'lang'          => false,
            'empty_message' => $this->l('Este campo es requerido'),
        ]);

        // client_secrect
        array_push($inputs, [
            'type'          => 'text',
            'label'         => $this->l('Client secrect'),
            'desc'          => $this->l('Client secrect'),
            'hint'          => $this->l('Client secrect'),
            'required'      => true,
            'name'          => 'client_secrect',
            'lang'          => false,
            'empty_message' => $this->l('Este campo es requerido'),
        ]);

        // cache_timelive
        array_push($inputs, [
            'type'          => 'text',
            'label'         => $this->l('Tiempo de vida del cache en horas'),
            'desc'          => $this->l('Tiempo de vida del cache en horas'),
            'hint'          => $this->l('Tiempo de vida del cache en horas'),
            'required'      => true,
            'name'          => 'cache_timelive',
            'lang'          => false,
            'empty_message' => $this->l('Este campo es requerido'),
        ]);

        // set values:
        if( Tools::isSubmit(static::FORM_ACTION_SUBMIT) )
        {
            $form->fields_value['endpoint']       = Tools::getValue('endpoint');
            $form->fields_value['client_id']      = Tools::getValue('client_id');
            $form->fields_value['client_secrect'] = Tools::getValue('client_secrect');
            $form->fields_value['cache_timelive'] = Tools::getValue('cache_timelive');
        }
        else{
            $form->fields_value['endpoint']       = $this->getConfigValue('endpoint');
            $form->fields_value['client_id']      = $this->getConfigValue('client_id');
            $form->fields_value['client_secrect'] = $this->getConfigValue('client_secrect');
            $form->fields_value['cache_timelive'] = $this->getConfigValue('cache_timelive');
        }

        return $inputs;
    }

    protected function calcDeliveryDate($quantityDate, $transportDays = 0 , $format = 'Y/m/d')
    {
        $dateObj = new \Datetime($quantityDate);

        #validate daysExclude:
        $daysExclude = $this->getConfigValue('exclude_days');
        $daysExclude = is_array($daysExclude) ? $daysExclude : static::DEFAULT_CONFIG['exclude_days'];
        $daysExclude = array_intersect($daysExclude, array_values(range(1,7)));

        if(count($daysExclude) > 6)
            $daysExclude = static::DEFAULT_CONFIG['exclude_days'];

        while($transportDays > 0)
        {
            $dateObj->add(new \DateInterval('P1D'));
            $infoDate  = (object) getdate( $dateObj->getTimestamp());
            if(in_array($infoDate->wday, $daysExclude))
                continue;

            $transportDays--;
        }

        return $dateObj->format($format);
    }

    public function hookdisplayShippingTime($params = [])
    {
        $idProduct     = (int) Tools::getValue('id_product');
        $idAttribute   = (int) Tools::getValue('id_product_attribute');
        $idShop        = $this->context->shop->id;
        $transportDays = (int) $this->getCarrierTime($idShop);
        $stock         = StockAvailable::getQuantityAvailableByProduct($idProduct, $idAttribute);

        # 1. Informar únicamente del stock disponible, siempre y cuando el stock disponible sea de al menos 12 botellas.
        if ($stock > 11)
            $shippingTime = $this->l('Recíbelo a partir del ') . $this->calcDeliveryDate(null, $transportDays);

        else{

            $dataApi = $this->apiGetData($idProduct, $idAttribute);

            switch(true)
            {
                # no tengo datos del api. fin de ejecucion.
                case (empty($dataApi['quantity_date'])):
                    return;

                # 2. Informar del stock disponible y del entrante disponible (1ª recepción) cuando el disponible sea menor a 12 botellas, y siempre y cuando la fecha del entrante disponible no sea igual a hoy.
                case ($dataApi['quantity_date'] != date('Y-m-d') && $stock > 0):
                    $shippingTime = $this->l('Recibe '. $stock .' unidades a partir del ' . $this->calcDeliveryDate(null, $transportDays) .'.');
                    $shippingTime.= $this->l('Si quieres más las recibirás a partir del ' . $this->calcDeliveryDate($dataApi['quantity_date'], $transportDays) );
                    break;

                #3. Informar de los días de abastecimiento cuando el stock disponible sea menor a 12 botellas y cuando el entrante disponible (1ª recepción) sea 0
                case (empty($dataApi['quantity']) && $stock > 0):
                    $shippingTime = $this->l('Recibe '. $stock .' unidades a partir del ' . $this->calcDeliveryDate(null, $transportDays) .'.');
                    $shippingTime.= $this->l('Si quieres más las recibirás a partir del ' . $this->calcDeliveryDate($dataApi['quantity_date'], $transportDays) );
                    break;

                #4. Informar únicamente del entrante disponible (1ª recepción) cuando el disponible sea 0
                #case ($stock == 0): redundancia.
                default:
                    $shippingTime = $this->l('Recibelo a partir del ' . $this->calcDeliveryDate($dataApi['quantity_date'], $transportDays) .'.');
                    break;
            }
        }

        $this->context->smarty->assign([ 'shippingTime'  => $shippingTime  ]);
        return $this->context->smarty->fetch($this->local_path . 'views/templates/hook/displayShippingTime.tpl');
    }
}
