<?php
/*
 * 2007-2015 PrestaShop
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please refer to http://www.prestashop.com for more information.
 *
 *  @author PrestaShop SA <contact@prestashop.com>
 *  @copyright  2007-2015 PrestaShop SA

 *  @license    http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 *  International Registered Trademark & Property of PrestaShop SA
 */

class Carrier_timeon extends Module
{
    const FORM_ACTION_SUBMIT = 'carrier_timeon_form';

    public $form  = [];

    public function __construct()
    {

        $this->name                   = 'carrier_timeon';
        $this->author                 = 'Webimpacto';
        $this->version                = '1.0';
        $this->controllers            = array('default');
        $this->bootstrap              = true;
        $this->need_instance          = 1;
        $this->displayName            = $this->l('Modulo para manejo tiempo de transito');
        $this->description            = $this->l('Este modulo permite establecer los dias o tiempos de transito a los transportistas segun la tienda');
        $this->confirmUninstall       = $this->l('Estas seguro de eliminar este modulo?');
        $this->ps_versions_compliancy = array('min' => '1.6', 'max' => _PS_VERSION_);

        parent::__construct();
    }

    public function install()
    {
        $sql = '
            create table {dbPrefix}carrier_times(
                id          integer   unsigned  NOT NULL AUTO_INCREMENT,
                id_shop     integer   unsigned  not null,
                id_carrier  integer   unsigned  not null,
                times       integer   unsigned  not null default 0,
                primary key (id),
                UNIQUE KEY unq1_{dbPrefix}carrier_times (id_shop, id_carrier, times),
                CONSTRAINT fk1_{dbPrefix}carrier_times  FOREIGN KEY (id_shop)    REFERENCES {dbPrefix}carrier_shop (id_shop)      on delete cascade on update cascade,
                CONSTRAINT fk3_{dbPrefix}carrier_times  FOREIGN KEY (id_carrier) REFERENCES {dbPrefix}carrier      (id_reference) on delete cascade on update cascade
            )ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci
        ';

        $sql = preg_replace('<({dbPrefix})>', _DB_PREFIX_, $sql);
        try{ Db::getInstance()->execute($sql, false); }
        catch(\Exception $e){ return false; }

        if (!parent::install() || !$this->registerHook('backOfficeHeader'))
            return false;
        else
            return true;
    }

    public function unistall()
    {
        $sql = 'drop table {dbPrefix}carrier_times';
        $sql = preg_replace('<({dbPrefix})>', _DB_PREFIX_, $sql);
        try{ Db::getInstance()->execute($sql, false); }
        catch(\Exception $e){ return false; }
        return parent::unistall();
    }

    public function HookBackOfficeHeader($params)
    {
        if (Tools::getValue('configure') != $this->name)
            return;

        $this->context->controller->addJquery();
        $this->context->controller->addJS($this->local_path.'/views/js/admin.js');
    }

    public function getContent()
    {
        if(isset($_POST['ajaxAction']))
            return $this->processAjaxRequest();

        $status = null;

        if(isset($_POST[static::FORM_ACTION_SUBMIT]))
        {
            $status = $this->processForm();
            if($status == true)
                $status = $this->displayConfirmation($this->l('Save successfully'));
            else
                $status = $this->displayError($this->l('Save fail'));
        }

        $this->context->smarty->assign([
            'form'     => $this->getForm(),
            'shopList' => json_encode($this->getShopMap()),
            'status'   => $status,
        ]);

        return $this->context->smarty->fetch($this->local_path.'views/templates/admin/admin.tpl');
    }

    protected function getShopMap()
    {
        $sql  = 'select id_shop as id, name from {db_prefix}shop where active = 1 and deleted = 0 order by name asc';
        $sql  = preg_replace('<({db_prefix})>', _DB_PREFIX_, $sql);
        $data = Db::getInstance()->executeS($sql, $array = true, false);
        return $data;
    }

    public function getForm()
    {
        $helper = new HelperForm();
        $helper->module = $this;
        $helper->name_controller = $this->name;
        $helper->identifier = $this->identifier;
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        $helper->currentIndex = AdminController::$currentIndex . '&configure=' . $this->name;

        $helper->languages                 = $this->context->controller->getLanguages();
        $helper->default_form_language     = $this->context->controller->default_form_language;
        $helper->allow_employee_form_lang  = $this->context->controller->allow_employee_form_lang;
        $helper->title                     = $this->displayName;
        $helper->submit_action             = static::FORM_ACTION_SUBMIT;

        $this->form[0] = array(
            'form' => array(
                'legend' => array('title' => $this->displayName),
                'submit' => array('title' => $this->l('Save')),
                'input'  => array(
                    array(
                        'type'     => 'select',
                        'label'    => $this->l('Seleccione la tienda'),
                        'desc'     => $this->l('Seleccione la tienda'),
                        'hint'     => $this->l('solo se muestran las tiendas activas para seleccionar'),
                        'required' => true,
                        'name'     => 'shop_id',
                        'options' => array(
                            'query' =>  [],
                        ),
                    ),
                    array(
                        'type'     => 'select',
                        'label'    => $this->l('Seleccione transportista'),
                        'desc'     => $this->l('Seleccione transportista'),
                        'hint'     => $this->l('solo se muestran los transportistas activos para la tienda seleccionada. El tranportista debe estar activo y pertenecer a la tienda seleccionada'),
                        'required' => true,
                        'name'     => 'carrier_id',
                        'options' => array(
                            'query' =>  [],
                        ),
                    ),
                    array(
                        'type'     => 'text',
                        'label'    => $this->l('Tiempo de transito'),
                        'desc'     => $this->l('Seleccione un tiempo de transito para el transportista'),
                        'hint'     => $this->l('timeon'),
                        'required' => true,
                        'name'     => 'timeon',
                        'lang'     => false,
                    ),
                ),
            ),
        );

        return $helper->generateForm($this->form);
    }

    protected function processAjaxRequest()
    {
        $action = $_POST['ajaxAction'];
        if($action == 'autocomplete')
        {
            $shopId = (isset($_POST['shopId'])) ? $_POST['shopId'] : 0;
            header ("Content-type: application/json");
            exit(json_encode($this->getDataAutocomplete($shopId)));
        }
    }

    protected function processForm()
    {
        $shopId      = (int) Tools::getValue('shop_id');
        $carrierId   = (int) Tools::getValue('carrier_id');
        $timeon      = (int) Tools::getValue('timeon');

        $shopList    = array_column($this->getShopMap(), 'id');
        $carrierList = array_column($this->getDataAutocomplete($shopId), 'id_reference');

        if(!in_array($shopId, $shopList))
            exit("shop id invalido");

        if(!in_array($carrierId, $carrierList))
            exit("carrier id invalido");

        $sql = sprintf('select * from {dbPrefix}carrier_times where id_shop = %s and id_carrier = %s', $shopId, $carrierId);
        $sql = preg_replace('<({dbPrefix})>', _DB_PREFIX_, $sql);

        $oldRecord = Db::getInstance()->executeS($sql);

        if(empty($oldRecord))
            $sql = sprintf('insert into {dbPrefix}carrier_times value(null, %s, %s , %s)', $shopId, $carrierId, $timeon);
        else
            $sql = sprintf('update {dbPrefix}carrier_times set times = %s where id=%s', $timeon, $oldRecord[0]['id'] );

        $sql = preg_replace('<({dbPrefix})>', _DB_PREFIX_, $sql);

        try{
            Db::getInstance()->execute($sql, false);
            return true;
        }
        catch(Exception $e)
        {
            return false;
        }
    }

    protected function getDataAutocomplete($shopId)
    {
        $shopId   = (int) $shopId;

        $sql = '
            SELECT DISTINCT
              pcs.id_shop
              ,c.id_carrier
              ,c.id_reference
              ,c.name
              ,ct.times

            from {db_prefix}shop as s
            inner join  {db_prefix}carrier_shop   AS pcs ON (pcs.id_shop   = s.id_shop)
            inner join  {db_prefix}carrier        AS c   ON (c.id_carrier  = pcs.id_carrier)
            LEFT  JOIN  {db_prefix}carrier_times  AS ct  ON (ct.id_carrier = c.id_reference and ct.id_shop = pcs.id_shop)
            where c.deleted = 0
            and pcs.id_shop = {shopId}
            and id_reference <> 0
        ';

        $sql  = preg_replace(['<({db_prefix})>', '<({shopId})>' ], [_DB_PREFIX_, $shopId], $sql);
        return Db::getInstance()->executeS($sql, true, false);
    }
}
