jQuery.fn.submitCarrierTimeon = function(options) {
    form = $(this);
    const shopList = options.shopList || {};
    const selectShop = form.find('select[name=shop_id]');
    const selectCarrier = form.find('select[name=carrier_id]');
    const inputTimeon = form.find('input[name=timeon]');
    const BtnSubmit = form.find('button[type=submit]');

    function setDisabled() {
        var attrs = { 'disabled': 'disabled', 'required': 'required' };
        selectCarrier.val('').html('').attr(attrs);
        inputTimeon.val('').html('').attr(attrs);
        BtnSubmit.attr('disabled', 'disabled');
    }

    function processError(data) {
        //alert("error");
        //console.log(data);
        window.location.reload(true);
    }

    function processAutocomplete(data) {
        selectCarrier.html('');
        selectCarrier.removeAttr('disabled');
        selectCarrier.append('<option value="">--</value>');
        selectCarrier.val('');
        selectCarrier.off();

        selectCarrier.on('change', function(e) {
            e.preventDefault();
            e.stopPropagation();

            if ($(this).val() == '') {
                inputTimeon.attr('disabled', 'disabled');
                inputTimeon.val('');
                return;
            }

            var timeon = $(this).find('option:selected').attr('data-timeon');

            if (isNaN(timeon) || timeon == null)
                timeon = '';

            inputTimeon.val(timeon);
            inputTimeon.data('default', timeon);
            inputTimeon.removeAttr('disabled');
            inputTimeon.off();

            inputTimeon.on('change', function(e) {
                e.preventDefault();
                e.stopPropagation();
                var val = $(this).val();
                if (isNaN(val) || val < 0 || $(this).data('default') == val) {
                    BtnSubmit.attr('disabled', 'disabled');
                    return;
                }

                val = val.split('.')
                val = val[0];

                if (val > 9999)
                    val = 9999;

                $(this).val(val);
                BtnSubmit.removeAttr('disabled');
            });
        });

        $(data).each(function(k, v) {
            selectCarrier.append('<option value="' + v.id_reference + '" data-timeon="' + v.times + '">' + v.name + '</option>');
        });
    }

    (function() {
        selectShop.append('<option vale="">--</option>');
        $(shopList).each(function(k, v) { selectShop.append('<option value="' + v.id + '">' + v.name + '</option>'); });
        setDisabled();

        inputTimeon.attr({
            'type': 'number',
            'min': '0',
            'max': '9999',
            'step': 1,
            'class': 'form-control',
        }).css('width', '200px');

        // register events:
        selectShop.on('change', function(e) {
            var el = $(this);
            e.preventDefault();
            e.stopPropagation();
            setDisabled();

            if (el.val() == '')
                return;

            $.ajax({
                    url: form.attr('href'),
                    data: { 'ajaxAction': 'autocomplete', 'shopId': el.val() },
                    type: 'post',
                })
                .done(processAutocomplete)
                .fail(processError);
        });

        form.on("submit", function(e) {
            if (BtnSubmit.attr('disabled')) {
                e.preventDefault();
                e.stopPropagation();
                return false;
            }
        });
    })();
};