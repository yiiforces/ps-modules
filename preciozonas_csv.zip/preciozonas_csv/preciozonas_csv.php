<?php

/*
 * 2007-2015 PrestaShop
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please refer to http://www.prestashop.com for more information.
 *
 *  @author PrestaShop SA <contact@prestashop.com>
 *  @copyright  2007-2015 PrestaShop SA

 *  @license    http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 *  International Registered Trademark & Property of PrestaShop SA
 */

class PrecioZonas_csv extends Module
{
    const FORM_ACTION_SUBMIT = 'upload_precios_zonas_csv';

    public $form  = [];

    public function __construct()
    {
        $this->name                   = 'preciozonas_csv';
        $this->author                 = 'Webimpacto';
        $this->version                = '1.0';
        $this->controllers            = array('default');
        $this->bootstrap              = true;
        $this->need_instance          = 1;
        $this->displayName            = $this->l('Cargar via csv los precios por zonas para los transportista');
        $this->description            = $this->l('Este modulo le permite cargar nuevos o actualizar , los precios de los transportistas segun su peso o rango de 
precio');
        $this->confirmUninstall       = $this->l('Estas segunro , de eliminar este modulo?');
        $this->ps_versions_compliancy = array('min' => '1.6', 'max' => _PS_VERSION_);

        parent::__construct();
    }

    public function install()
    {
        return
            parent::install();
    }

    public function unistall()
    {
        return
            parent::install();
    }

    public function hookActionCarrierUpdate($params)
    {
        $this->_clearCache('*');
    }

    public function getContent()
    {
        return
            $this->postProcess() . $this->getForm();
    }

    protected function getCarriersActives()
    {
        $sql = '
            SELECT a.id_carrier, a.id_reference , a.name, a.url, b.id_shop, b.id_lang, b.delay
            FROM `{db_prefix}carrier` AS a
            INNER JOIN `{db_prefix}carrier_lang`                 AS b     ON (a.id_carrier = b.id_carrier {ShopRestrictionOnLang} AND b.id_lang = {languageId})
            LEFT  JOIN `{db_prefix}carrier_tax_rules_group_shop` AS ctrgs ON (a.id_carrier = ctrgs.id_carrier AND ctrgs.id_shop={shopId})
            WHERE a.deleted = 0
            AND   a.is_free = 0
            ORDER BY a.name ASC
        ';

        $matches = [
           '<({db_prefix})>',
           '<({ShopRestrictionOnLang})>',
           '<({languageId})>',
           '<({shopId})>',
        ];

        $replaces = [
            _DB_PREFIX_,
            Shop::addSqlRestrictionOnLang('b'),
            (int) $this->context->language->id,
            (int) $this->context->shop->id
        ];

        $sql = preg_replace($matches,$replaces, $sql);
        return Db::getInstance()->executeS($sql, true, false);
    }

    protected function getCarriesMap()
    {
        $list = [];
        foreach($this->getCarriersActives() as $value)
        {
            array_push($list, [
                'id'   => $value['id_carrier'],
                'name' => $value['name'],
            ]);
        }
        return $list;
    }

    protected function getZonesMap()
    {
        $list = [];
        foreach(Zone::getZones(true) as $value)
        {
            array_push($list, [
                'id'   => $value['id_zone'],
                'name' => $value['name'],
            ]);
        }

        return $list;
    }

    protected function getCsvDelimiterMap()
    {
        return [
            ['id' => ','   , 'name' => ', (por defecto)'],
            ['id' => ';'   , 'name' => ';'],
            ['id' => '|'   , 'name' => '|'],
            ['id' => 'tab' , 'name' => 'tab'],
            ['id' => ' '   , 'name' => $this->l('espacio en blanco')],
        ];
    }

    protected function getDataFromCsv($filename, $delimiter)
    {
        $data = [];

        if($delimiter == 'tab')
            $delimiter = "\t";
        try{
            $content = file_get_contents($filename);

            foreach(explode(PHP_EOL, $content) as $line)
            {
                $line = str_getcsv($line , $delimiter);

                if(count($line) < 2)
                    continue;

                array_push($data, [
                    'min'   => $line[0],
                    'max'   => $line[1],
                    'price' => $line[2],
                ]);
            }
        }
        catch(\Exception $e){
            return [];
        }

        return $data;
    }

    public function getForm()
    {
        $helper = new HelperForm();
        $helper->module = $this;
        $helper->name_controller = $this->name;
        $helper->identifier = $this->identifier;
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        $helper->currentIndex = AdminController::$currentIndex . '&configure=' . $this->name;

        $helper->languages                 = $this->context->controller->getLanguages();
        $helper->default_form_language     = $this->context->controller->default_form_language;
        $helper->allow_employee_form_lang  = $this->context->controller->allow_employee_form_lang;
        $helper->title                     = $this->displayName;
        $helper->submit_action             = static::FORM_ACTION_SUBMIT;

        # set options:
        $optionsZones =  $this->getZonesMap();
        array_unshift($optionsZones , ['id' => null, 'name' => '--']);

        $optionsCarries = $this->getCarriesMap();
        array_unshift($optionsCarries , ['id' => null, 'name' => '--']);

        $this->form[0] = array(
            'form' => array(
                'legend' => array('title' => $this->displayName),
                'submit' => array('title' => $this->l('Save')),
                'input' => array(
                    array(
                        'type'     => 'select',
                        'label'    => $this->l('Seleccione una zona'),
                        'desc'     => $this->l('Seleccionar zona'),
                        'hint'     => $this->l('Seleccionar zona'),
                        'name'     => 'id_zone',
                        'required' => true,
                        'options' => array(
                            'query' =>  $optionsZones,
                            'id'    => 'id',
                            'name'  => 'name'
                        )
                    ),
                    array(
                        'type' => 'select',
                        'label' => $this->l('Seleccion un Transportista'),
                        'desc' => $this->l('Seleccione él transportista'),
                        'hint' => $this->l('Seleccione él transportista'),
                        'name' => 'id_carrier',
                        'required' => true,
                        'lang' => true,
                        'options' => array(
                            'query' => $optionsCarries,
                            'id'    => 'id',
                            'name'  => 'name'
                        )
                    ),
                    array(
                        'type'     => 'select',
                        'label'    => $this->l('Delimitador de csv'),
                        'desc'     => $this->l('Delimitador de csv (opcional por defecto sera ",")'),
                        'hint'     => $this->l('Delimitador de csv (opcional por defecto sera ",")'),
                        'name'     => 'csv_delimiter',
                        'options' => array(
                            'query' =>  $this->getCsvDelimiterMap(),
                            'id'    => 'id',
                            'name'  => 'name'
                        )
                    ),
                    array(
                        'type'     => 'file',
                        'required' => true,
                        'label'    => $this->l('Upload CSV File'),
                        'desc'     => $this->l('Upload CSV File'),
                        'hint'     => $this->l('Upload CSV File'),
                        'name'     => 'csv',
                        'lang'     => true,
                    ),
                ),
            ),
        );

        return $helper->generateForm($this->form);
    }

    protected function sendError($flagError)
    {
        exit($flagError); // @todo hacer el error de presta.
    }


    public function postProcess()
    {
        if(!Tools::isSubmit(static::FORM_ACTION_SUBMIT))
            return;

        $idZone         = Tools::getValue('id_zone');
        $idCarrier      = Tools::getValue('id_carrier');
        $csv            = Tools::getValue('file');
        $csvDelimiter   = Tools::getValue('csv_delimiter');

        if(!in_array($csvDelimiter, array_column($this->getCsvDelimiterMap(), 'id')))
            $csvDelimiter = ',';

        #validate data:
        $errors = null;

        if(!in_array($idZone, array_column($this->getZonesMap(), 'id')))
            $errors.= $this->l('El campo zona es invalido');

        if(!in_array($idCarrier, array_column($this->getCarriesMap(), 'id')))
            $errors.= '<br>' . $this->l('El campo transportista es invalido');

        if(!isset($_FILES['csv']))
            $errors.= '<br>' . $this->l('El archivo csv es requerido');

        else if($_FILES['csv']['error'] != 0)
            $errors.= '<br>' . $this->l('El archivo csv es requerido');

        // parse csv to array;
        $dataCsv = $this->getDataFromCsv($_FILES['csv']['tmp_name'], $csvDelimiter);
        if(empty($dataCsv))
            $errors.= '<br>' . $this->l('El archivo csv no tiene el formato valido ó sus columnas estan incompletas');

        if(!is_null($errors))
            return $this->sendError($errors);

        $carrier = new Carrier((int) $idCarrier);

        if(!Validate::isLoadedObject($carrier))
            $this->sendError( $this->l('El campo transportista es invalido') );

        if(empty($carrier->getZone($idZone)))
            $carrier->addZone($idZone);

        $tbName = ($carrier->getShippingMethod() == Carrier::SHIPPING_METHOD_PRICE) ? 'range_price' : 'range_weight';

        $dump = [];

        $sql = '
            select distinct
               d.id_delivery
              ,z.id_zone
              ,r.delimiter1 as min
              ,r.delimiter2 as max
              ,d.price

            from ps_carrier as c
            inner join {db_prefix}{rangeType}  as r on r.id_carrier     = c.id_carrier
            inner join {db_prefix}delivery     as d on d.id_{rangeType} = r.id_{rangeType}
            inner join {db_prefix}zone         as z on z.id_zone        = d.id_zone

            where c.id_carrier  = {idCarrier}
            and z.id_zone <> {idZone}
            and z.id_zone in ({inZones})
            and r.delimiter1  = {min}
            and r.delimiter2  = {max}
            and d.price > 0
            order by z.id_zone asc, d.id_delivery desc
        ';

        $in = [];
        foreach($carrier->getZones() as $zone){
            if($zone['id_zone'] == $idZone)
                continue;

            $in[] = $zone['id_zone'];
        }
        $in = implode(',', $in);

        $sql   = preg_replace('<({db_prefix})>' , _DB_PREFIX_ , $sql);
        $sql   = preg_replace('<({idZone})>'    , $idZone     , $sql);
        $sql   = preg_replace('<({idCarrier})>' , $idCarrier  , $sql);
        $sql   = preg_replace('<({rangeType})>' , $tbName     , $sql);
        $sql   = preg_replace('<({inZones})>'   , $in         , $sql);

        $ranges = [];
        foreach($dataCsv as $key => $csv)
        {
            $csv['min']   = (float)$csv['min'];
            $csv['max']   = (float)$csv['max'];
            $csv['price'] = (float) str_replace(',', '.', $csv['price']);

            if($csv['min'] >= $csv['max'])
                continue;

            $ranges[] = [
                'id'  => null,
                'min' => $csv['min'],
                'max' => $csv['max'],
            ];

            $dump[$idZone][] = [
                'min'   => $csv['min'],
                'max'   => $csv['max'],
                'price' => $csv['price'],
            ];

            $sqlLoop = preg_replace('<({min})>' , $csv['min'] , $sql);
            $sqlLoop = preg_replace('<({max})>' , $csv['max'] , $sqlLoop);
            $oldData = Db::getInstance()->executeS($sqlLoop, true, false);

            if(!empty($oldData))
            {
                $zonesAdd = [];
                foreach($oldData as $keyOld =>$valueOld)
                {
                    if(in_array($valueOld['id_zone'] ,  $zonesAdd))
                        continue;

                    array_push($zonesAdd, $valueOld['id_zone']);

                    $dump[$valueOld['id_zone']][] = [
                        'min'   => $csv['min'],
                        'max'   => $csv['max'],
                        'price' => $valueOld['price'],
                    ];
                }
            }
        }

        Db::getInstance()->delete('range_weight' , 'id_carrier = ' . (int) $idCarrier);
        Db::getInstance()->delete('range_price'  , 'id_carrier = ' . (int) $idCarrier);

        foreach ($ranges as $key => $value)
        {
            // esto me crea un duplicado!
            $range= $carrier->getRangeObject();
            $range->id_carrier = $carrier->id;
            $range->delimiter1 = $value['min'];
            $range->delimiter2 = $value['max'];
            $range->save();
            $ranges[$key]['id'] =  $range->id;
        }

        Db::getInstance()->delete('delivery' , 'id_carrier = ' . (int) $idCarrier);

        foreach($dump as $zone => $items)
        {
            foreach($items as $key => $item)
            {
                $item    = (object) $item;
                $rangeP  = ($carrier->getShippingMethod() == Carrier::SHIPPING_METHOD_PRICE  ? $ranges[$key]['id'] : 'null');
                $rangeW  = ($carrier->getShippingMethod() == Carrier::SHIPPING_METHOD_WEIGHT ? $ranges[$key]['id'] : 'null');
                $price   = $item->price > 0 ? $item->price : 0;
                $sql     = "insert into `" . _DB_PREFIX_ ."delivery` values(null,null,null,{$carrier->id},$rangeP,$rangeW,$zone,$price);";
                Db::getInstance()->execute($sql);
            }
        }

        return $this->displayConfirmation($this->l('Upload CSV File Successfully'));
    }
}

